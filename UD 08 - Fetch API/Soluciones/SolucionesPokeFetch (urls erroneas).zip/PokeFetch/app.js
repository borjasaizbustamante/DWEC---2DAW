// Seleccionamos elementos del DOM
const inputPokemon = document.getElementById('input-pokemon');
const btnBuscar = document.getElementById('btn-buscar');
const estado = document.getElementById('estado');
const resultado = document.getElementById('resultado');

// URL base de la PokeAPI
const API_BASE = 'https://pokeapi.co/api/v2/pokemon/';

// Función principal: busca un Pokémon por nombre o ID
async function buscarPokemon(nombreOId) {
    // Normalizamos el texto: quitamos espacios y pasamos a minúsculas
    const query = nombreOId.trim().toLowerCase();

    // Si está vacío, mostramos aviso y salimos
    if (!query) {
        estado.textContent = 'Introduce un nombre o ID de Pokémon.';
        resultado.innerHTML = '';
        return;
    }

    // Mostramos estado de "cargando"
    estado.textContent = 'Cargando...';
    resultado.innerHTML = '';

    try {
        // Hacemos la petición a la API
        const response = await fetch(API_BASE + query);

        // Comprobamos si la respuesta es correcta (status 2xx)
        if (!response.ok) {
            // Si es 404, Pokémon no encontrado
            if (response.status === 404) {
                estado.textContent = 'No se ha encontrado ningún Pokémon con ese nombre/ID.';
                resultado.innerHTML = '';
                return;
            } else {
                // Otro tipo de error HTTP
                throw new Error('Error HTTP: ' + response.status);
            }
        }

        // Convertimos la respuesta a JSON
        const data = await response.json();

        // Mostramos el Pokémon en la página
        mostrarPokemon(data);

        // Actualizamos el estado
        estado.textContent = 'Pokémon encontrado correctamente.';

    } catch (error) {
        // Errores de red u otros errores de ejecución
        console.error(error);
        estado.textContent = 'Ha ocurrido un error al conectar con el servidor.';
        resultado.innerHTML = '';
    }
}

// Función auxiliar: pinta la "tarjeta" del Pokémon en el DOM
function mostrarPokemon(pokemon) {
    const nombre = pokemon.name;                   // p.ej. "pikachu"
    const id = pokemon.id;                         // p.ej. 25
    const imagen = pokemon.sprites.front_default;  // URL del sprite
    const tipos = pokemon.types;                   // Array de tipos

    // HTML para los tipos, con clases para colorearlos
    const tiposHTML = tipos
        .map(t => `<span class="tipo ${t.type.name}">${t.type.name}</span>`)
        .join('');

    const cardHTML = `
    <div class="pokemon-card">
      <h2>#${id} – ${nombre}</h2>
      ${imagen ? `<img src="${imagen}" alt="${nombre}">` : '<p>(Sin imagen)</p>'}
      <div class="tipos">
        <strong>Tipos:</strong> ${tiposHTML || 'Desconocido'}
      </div>
    </div>
  `;

    resultado.innerHTML = cardHTML;
}

// Evento click en el botón "Buscar"
btnBuscar.addEventListener('click', () => {
    const valor = inputPokemon.value;
    buscarPokemon(valor);
});

// Búsqueda al pulsar Enter dentro del input (mejora)
inputPokemon.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
        buscarPokemon(inputPokemon.value);
    }
});
