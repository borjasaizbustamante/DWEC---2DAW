package com.pokedex.pokeFetch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PokeFetchApplicationTests {

	@Test
	void contextLoads() {
	}

}
