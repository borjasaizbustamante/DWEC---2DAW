package com.pokedex.pokeFetch;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@RestController
public class PokemonController {

	private static final Path PROJECT_DIR = resolveProjectDir();
	private static final Path FILES_DIR = PROJECT_DIR.resolve(Paths.get("src", "main", "resources", "files"))
			.normalize();

	private static Path resolveProjectDir() {
		Path defaultPath = Paths.get("C:", "Users", "borja", "eclipse-workspace", "pokeFetch").toAbsolutePath()
				.normalize();
		if (Files.exists(defaultPath.resolve(Paths.get("src", "main", "resources", "files")))) {
			return defaultPath;
		}
		return Paths.get("").toAbsolutePath().normalize();
	}

	@GetMapping(value = { "/{id}", "/pokemon/{id}" }, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> getPokemonByPath(@PathVariable(name = "id", required = false) String id) {
		return handleRequest(id);
	}

	@GetMapping(value = { "", "/", "/pokemon" }, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> getPokemonByQuery(@RequestParam(name = "id", required = false) String id) {
		return handleRequest(id);
	}

	private ResponseEntity<String> handleRequest(String id) {
		System.out.println("Requesting pokemon " + id);

		// Requirement: If not a number is given, or something that is not a number is
		// provided, answer with a 500
		if (id == null || id.trim().isEmpty() || !id.trim().matches("^\\d+$")) {
			System.out.println(id + " is not a pokemon number");
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}

		String sanitizedId = id.trim();
		Path targetFile = FILES_DIR.resolve("pokemon" + sanitizedId + ".json").normalize();

		// Requirement: If there is no json file for the given number, the server must
		// answer with a 404
		if (!Files.exists(targetFile) || !Files.isRegularFile(targetFile)) {
			System.out.println(id + " is not a valid pokemon [1 - 150]");
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}

		// Requirement: If there is a file in the form pokemon{id}.json, send it to the
		// client as an answer (HTTP 200)
		try {
			String content = Files.readString(targetFile, StandardCharsets.UTF_8);
			System.out.println("Pokemon info delivered...");
			return ResponseEntity.ok().header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).body(content);
		} catch (IOException e) {
			System.out.println("Something went wrong... ");
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<Void> handleAllExceptions() {
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
	}
}
