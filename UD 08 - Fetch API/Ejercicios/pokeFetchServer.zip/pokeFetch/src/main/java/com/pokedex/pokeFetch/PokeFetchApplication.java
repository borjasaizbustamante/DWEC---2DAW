package com.pokedex.pokeFetch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PokeFetchApplication {

	public static void main(String[] args) {
		SpringApplication.run(PokeFetchApplication.class, args);
	}

}
