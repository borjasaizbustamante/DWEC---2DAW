package com.daw.htmx.server.HtmxServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@SpringBootApplication
@RestController

// We let request from everywhere
@CrossOrigin(origins = "*")
public class HtmxServerApplication {

	// EXAMPLE 1 - Simpel GET that returns a simple HTML
	@GetMapping(value = "/api/serverTime", produces = MediaType.TEXT_HTML_VALUE)
	public String getServerTime() {
		String horaActual = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"));
		String response = "<div class='alerta'>Hora del servidor Java: <strong>" + horaActual + "</strong></div>";
		System.out.println("Server says: " + response);
		return response;
	}

	// EXAMPLE 2: A real-time search (ideal for hx-trigger="keyup changed delay:300ms")
	@GetMapping(value = "/api/find", produces = MediaType.TEXT_HTML_VALUE)
	public String getStudents(@RequestParam(defaultValue = "") String query) {
		List<String> alumnos = List.of("Ane", "Unai", "Maite", "Iker", "Leire", "Jon");

		if (query.isBlank()) {
			return "<li>Escribe un nombre para buscar...</li>";
		}

		StringBuilder html = new StringBuilder();
		alumnos.stream().filter(nombre -> nombre.toLowerCase().contains(query.toLowerCase()))
				.forEach(nombre -> html.append("<li>").append(nombre).append("</li>"));

		String response = html.isEmpty() ? "<li>No se encontraron alumnos</li>" : html.toString();
		System.out.println("Server says: " + response);
		return response;
	}

	// EXAMPLE 3: A POST from an HTMX Form
	@PostMapping(value = "/api/sayHello", produces = MediaType.TEXT_HTML_VALUE)
	public String saludarUsuario(@RequestParam String nombre) {
		// Remove the HTML tags sent by error... 
		String nombreSeguro = nombre.replace("<", "&lt;").replace(">", "&gt;");
		String response = "<p style='color: green;'>¡Hola, <strong>" + nombreSeguro
				+ "</strong>! Respuesta procesada por Java.</p>";
		System.out.println("Server says: " + response);
		return response;
	}

	public static void main(String[] args) {
		SpringApplication.run(HtmxServerApplication.class, args);
	}

}
