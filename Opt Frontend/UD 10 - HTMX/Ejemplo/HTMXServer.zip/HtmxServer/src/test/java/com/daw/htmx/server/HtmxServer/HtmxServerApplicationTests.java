package com.daw.htmx.server.HtmxServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HtmxServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
